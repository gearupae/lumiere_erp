<?php

# Version 2.3.0
$lang['menu_builder']        = 'Ustawienia menu';
$lang['main_menu']           = 'Główne menu';
$lang['setup_menu']          = 'Menu ustawień';
$lang['utilities_menu_icon'] = 'Ikona';
$lang['active_menu_items']   = 'Aktywne pozycje menu';
$lang['utilities_menu_save'] = 'Zapisz menu';
