<?php

# Version 2.3.0
$lang['menu_builder']        = 'Configurar Menu';
$lang['main_menu']           = 'Menu Principal';
$lang['setup_menu']          = 'Configurar Menu';
$lang['utilities_menu_icon'] = 'Icone';
$lang['active_menu_items']   = 'Itens Ativos do Menu';
$lang['utilities_menu_save'] = 'Salvar Menu';
