<?php

# Version 2.3.0
$lang['menu_builder']        = 'Menu instellingen';
$lang['main_menu']           = 'Hoofdmenu';
$lang['setup_menu']          = 'Instellingen menu';
$lang['utilities_menu_icon'] = 'Icon';
$lang['active_menu_items']   = 'Actieve menu items';
$lang['utilities_menu_save'] = 'Sla menu op';
