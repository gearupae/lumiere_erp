<?php

# Version 2.3.0
$lang['menu_builder']        = 'تنظيمات منو';
$lang['main_menu']           = 'منوي اصلي';
$lang['setup_menu']          = 'منوي تنظيمات';
$lang['utilities_menu_icon'] = 'آيکون';
$lang['active_menu_items']   = 'موارد فعال منو';
$lang['utilities_menu_save'] = 'منوي ذخيره';
