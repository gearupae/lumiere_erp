<?php

# Version 2.3.0
$lang['menu_builder']        = '菜单设置';
$lang['main_menu']           = '主菜单';
$lang['setup_menu']          = '设置菜单';
$lang['utilities_menu_icon'] = '图标';
$lang['active_menu_items']   = '活动菜单项';
$lang['utilities_menu_save'] = '保存菜单';
