<?php

defined('BASEPATH') or exit('No direct script access allowed');

add_option('aside_menu_active', '[]');
add_option('setup_menu_active', '[]');
