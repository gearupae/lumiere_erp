<?php

# Version 2.3.0
$lang['auto_backup_options_updated']     = 'Opcions de còpia de seguretat automàtica actualitzades';
$lang['auto_backup_every']               = 'Crear còpia de seguretat cada X dies';
$lang['auto_backup_enabled']             = 'Habilitat (Requereix Cron)';
$lang['auto_backup']                     = 'Còpia de seguretat automàtica';
$lang['backup_delete']                   = 'Còpia eliminaa';
$lang['backup_success']                  = 'Còpia de seguretat realitzada';
$lang['utility_backup']                  = 'Còpia de seguretat base dades';
$lang['utility_create_new_backup_db']    = 'Crear còpia seguretat base dades';
$lang['utility_backup_table_backupname'] = 'Còpia seguretat';
$lang['utility_backup_table_backupsize'] = 'Tamany còpia seguretat';
$lang['utility_backup_table_backupdate'] = 'Data';
$lang['utility_db_backup_note']          = 'Nota: Degut al temps d\'execució limitat i memòria disponible per a PHP, pot ser que no es puguin fer còpies de seguretat de bases de dades molt grans. Si la seva base de dades és molt gran potser haurà de fer còpies de seguretat directament des del seu servidor SQL, o demanar que li ho faci l\'administrador del servidor si vostè no té privilegis de root.';
$lang['delete_backups_older_then']       = 'Auto esborrar còpies de seguretat que tinguin més de X dies (establir a 0 per desactivar-ho)';
$lang['auto_backup_hour']                = 'Hour of day to perform backup';
