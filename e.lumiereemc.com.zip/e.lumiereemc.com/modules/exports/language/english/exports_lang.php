<?php
$lang['csv_export'] = 'CSV Export';
$lang['csv_exports'] = 'CSV Exports';
$lang['contacts'] = 'Contacts';
$lang['csv_export_select_type'] = 'Export Type';
$lang['csv_export_all_time'] = 'All Time';
$lang['csv_export_three_months'] = 'Last 3 Months';
$lang['csv_export_six_months'] = 'Last 6 Months';
$lang['csv_export_twelve_months'] = 'Last 12 Months';
$lang['csv_export_from_date'] = 'From Date';
$lang['csv_export_to_date'] = 'To Date';
$lang['csv_export_button'] = 'Export';
