<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="number-purchase-orders-report" class="hide">
   <div class="row">
     <figure class="highcharts-figure col-md-12">
       <div id="container_number_purchase_orders"></div>
       
      </figure>
   </div>
</div>