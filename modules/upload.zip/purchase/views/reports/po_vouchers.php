<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="list_po_voucher" class="hide">
   <div class="row">
      <div class="col-md-4">
         <div class="form-group">
            
         </div>
      </div>
      <div class="clearfix"></div>
   </div>
<table class="table table-po-voucher-report scroll-responsive">
   <thead>
      <tr>
         <th><?php echo _l('purchase_order'); ?></th>
         <th><?php echo _l('date'); ?></th>
         <th><?php echo _l('type'); ?></th>
         <th><?php echo _l('project'); ?></th>
         <th><?php echo _l('department'); ?></th>
         <th><?php echo _l('vendor'); ?></th>
         <th><?php echo _l('approval_status'); ?></th>
         <th><?php echo _l('delivery_status'); ?></th>
         <th><?php echo _l('payment_status'); ?></th>
      </tr>
   </thead>
   <tbody></tbody>
</table>
</div>
